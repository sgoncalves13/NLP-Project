# **Reddit Humor Captioning Repository**

Welcome to the **Reddit Humor Captioning Repository**, where we explore various approaches to generate captions for humorous content scraped from Reddit. This repository includes tools for **web scraping** Reddit posts using `praw` and generating captions using **BLIP**, **CLIP + mBART50**, and **OpenAI's ChatGPT-4**.

---

## **Repository Contents**

### 1. **CaptioningOpenAi.ipynb**
   - **Purpose**: Generates captions for images using OpenAI's ChatGPT-4 API.
   - **Description**: 
     - Takes images (e.g., from Reddit posts) as input.
     - Utilizes prompt engineering to produce humorous captions in **natural language**.
     - Stores results in a JSON file for further analysis or use.
   - **Requirements**: Ensure you have access to the OpenAI API with multimodal support.

---

### 2. **humor-reddit-scrapper.ipynb**
   - **Purpose**: Scrapes Reddit posts from specified subreddits using `praw` for further captioning tasks.
   - **Description**:
     - Connects to Reddit via the `praw` library.
     - Extracts posts (titles, images, or other media) from humor-related subreddits.
     - Saves the data (e.g., image URLs) for downstream captioning tasks.
   - **Usage**:
     - Define your target subreddits (e.g., `r/funny`, `r/memes`).
     - Run the notebook to collect and store Reddit content.

---

### 3. **CLIPVisionTransformer.ipynb**
   - **Purpose**: Generates captions using the **CLIP Vision Transformer** and **mBART50**.
   - **Description**:
     - Processes images by combining CLIP (for visual feature extraction) with mBART50 (for multilingual caption generation).
     - Produces captions directly in the desired language (e.g., Spanish).
     - Stores results in a structured JSON file for analysis.
   - **Requirements**:
     - Install dependencies listed in `requirements.txt` before running.
     - Make sure to have Hugging Face's `transformers` library and other necessary tools installed.

---

## **Setup Instructions**

### **1. Clone the Repository**
```bash
git clone https://github.com/your-username/reddit-humor-captioning.git
cd reddit-humor-captioning
```

### **2. Install Requirements for CLIP + mBART50**
```bash
pip install -r requirements.txt
```

### **3. Access the OpenAI API**
For using ChatGPT-4 in `CaptioningOpenAi.ipynb`, ensure:
- You have an OpenAI API key.
- Multimodal capabilities are enabled for your account.

---

## **How the Code Works**

### **Step 1: Scraping Reddit Posts**
- Use `humor-reddit-scrapper.ipynb` to gather data (e.g., image URLs, titles) from specified subreddits.
- Results are stored in a format suitable for captioning tasks.

### **Step 2: Generating Captions**
- **BLIP** (integrated in `humor-reddit-scrapper.ipynb`):
  - Processes images for basic captioning.
  - Limited in contextual interpretation and humor detection.
- **CLIP + mBART50** (`CLIPVisionTransformer.ipynb`):
  - Combines CLIP for visual understanding with mBART50 for multilingual caption generation.
  - Generates more descriptive captions in Spanish or other languages.
- **ChatGPT-4** (`CaptioningOpenAi.ipynb`):
  - Uses advanced reasoning to create humorous and natural captions.
  - Requires API access and proper prompt engineering.

---

## **Comparison of Captioning Approaches**

| Model                | Strengths                                  | Limitations                             |
|----------------------|--------------------------------------------|-----------------------------------------|
| **BLIP**             | Basic image descriptions.                 | Limited humor/contextual understanding. |
| **CLIP + mBART50**   | Multilingual captions with good accuracy.  | Struggles with humor and context.       |
| **OpenAI ChatGPT-4** | Excels in humor and natural language.      | API costs and scalability.              |

---

## **Contributing**
Feel free to contribute by:
- Improving caption generation models.
- Adding more subreddits to scrape.
- Enhancing prompt engineering techniques.

---

## **License**
This repository is licensed under the [MIT License](LICENSE).

---

### **Happy Captioning!** 😊